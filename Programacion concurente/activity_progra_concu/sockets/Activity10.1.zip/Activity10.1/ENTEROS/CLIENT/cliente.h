
#define PORT_NUM 8888
#define LOCAL_HOST "127.0.0.1"

int connection();
int close(int sock);
